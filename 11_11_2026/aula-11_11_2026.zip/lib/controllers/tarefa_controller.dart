import 'package:flutter/foundation.dart';
import '../models/tarefa.dart';
import '../repositories/tarefa_repositorio.dart';

class TarefaController extends ChangeNotifier {
  final TarefaRepositorio _repositorio;

  TarefaController(this._repositorio);

  List<Tarefa> get tarefas => List.unmodifiable(_repositorio.obterTodas());

  void cadastrar(String titulo) {
    final texto = titulo.trim();
    if (texto.isEmpty) return;

    final nova = Tarefa(
      id: DateTime.now().microsecondsSinceEpoch,
      titulo: texto,
    );

    _repositorio.salvarTodas([nova, ..._repositorio.obterTodas()]);
    notifyListeners();
  }

  void alternar(Tarefa tarefa, bool concluida) {
    final restantes =
        _repositorio.obterTodas().where((t) => t.id != tarefa.id).toList();
    final atualizada = tarefa.copyWith(concluida: concluida);

    _repositorio.salvarTodas(
      concluida ? [...restantes, atualizada] : [atualizada, ...restantes],
    );
    notifyListeners();
  }
}
