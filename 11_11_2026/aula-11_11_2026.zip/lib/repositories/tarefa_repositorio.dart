import '../models/tarefa.dart';

abstract class TarefaRepositorio {
  List<Tarefa> obterTodas();
  void salvarTodas(List<Tarefa> tarefas);
}
