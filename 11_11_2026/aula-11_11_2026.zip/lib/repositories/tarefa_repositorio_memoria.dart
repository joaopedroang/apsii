import '../models/tarefa.dart';
import 'tarefa_repositorio.dart';

class TarefaRepositorioMemoria implements TarefaRepositorio {
  List<Tarefa> _tarefas = [];

  @override
  List<Tarefa> obterTodas() => List.of(_tarefas);

  @override
  void salvarTodas(List<Tarefa> tarefas) {
    _tarefas = List.of(tarefas);
  }
}
