import 'package:flutter/material.dart';
import '../controllers/tarefa_controller.dart';
import '../widgets/formulario_tarefa.dart';
import '../widgets/lista_tarefas.dart';

class TelaTodoList extends StatelessWidget {
  final TarefaController controller;

  const TelaTodoList({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('To do List')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            FormularioTarefa(onCadastrar: controller.cadastrar),
            const SizedBox(height: 12),
            Expanded(
              child: ListenableBuilder(
                listenable: controller,
                builder: (context, _) => ListaTarefas(
                  tarefas: controller.tarefas,
                  onAlternar: controller.alternar,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
