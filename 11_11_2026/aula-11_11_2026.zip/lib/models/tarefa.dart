class Tarefa {
  final int id;
  final String titulo;
  final bool concluida;

  const Tarefa({
    required this.id,
    required this.titulo,
    this.concluida = false,
  });

  Tarefa copyWith({bool? concluida}) {
    return Tarefa(
      id: id,
      titulo: titulo,
      concluida: concluida ?? this.concluida,
    );
  }
}
