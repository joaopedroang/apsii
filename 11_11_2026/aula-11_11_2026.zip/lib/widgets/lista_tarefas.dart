import 'package:flutter/material.dart';
import '../models/tarefa.dart';
import 'item_tarefa.dart';

class ListaTarefas extends StatelessWidget {
  final List<Tarefa> tarefas;
  final void Function(Tarefa tarefa, bool concluida) onAlternar;

  const ListaTarefas({
    super.key,
    required this.tarefas,
    required this.onAlternar,
  });

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: tarefas.length,
      itemBuilder: (context, index) {
        final tarefa = tarefas[index];
        return ItemTarefa(
          key: ValueKey(tarefa.id),
          tarefa: tarefa,
          onAlterado: (concluida) => onAlternar(tarefa, concluida),
        );
      },
    );
  }
}
