import 'package:flutter/material.dart';
import '../models/tarefa.dart';

class ItemTarefa extends StatelessWidget {
  final Tarefa tarefa;
  final ValueChanged<bool> onAlterado;

  const ItemTarefa({
    super.key,
    required this.tarefa,
    required this.onAlterado,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(
        tarefa.titulo,
        style: TextStyle(
          decoration: tarefa.concluida
              ? TextDecoration.lineThrough
              : TextDecoration.none,
        ),
      ),
      trailing: Checkbox(
        value: tarefa.concluida,
        onChanged: (valor) => onAlterado(valor ?? false),
      ),
    );
  }
}
