import 'package:flutter/material.dart';

class FormularioTarefa extends StatefulWidget {
  final ValueChanged<String> onCadastrar;

  const FormularioTarefa({super.key, required this.onCadastrar});

  @override
  State<FormularioTarefa> createState() => _FormularioTarefaState();
}

class _FormularioTarefaState extends State<FormularioTarefa> {
  final TextEditingController _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _enviar() {
    widget.onCadastrar(_controller.text);
    _controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TextField(
          controller: _controller,
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.note),
            hintText: 'Tarefa',
            border: OutlineInputBorder(),
          ),
          onSubmitted: (_) => _enviar(),
        ),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _enviar,
            child: const Text('Cadastrar'),
          ),
        ),
      ],
    );
  }
}
